import { App } from './modules/components.js';

const { createApp } = Vue;

createApp(App).mount('#app');